c

      COMMON /COMWRTC/ cvals
C
C           CVALS   - character*80 array 
