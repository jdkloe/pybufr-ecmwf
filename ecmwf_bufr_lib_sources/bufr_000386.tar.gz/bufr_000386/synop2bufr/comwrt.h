c

      COMMON /COMWRT/ values
C
C           VALUES   - real*8 array 
