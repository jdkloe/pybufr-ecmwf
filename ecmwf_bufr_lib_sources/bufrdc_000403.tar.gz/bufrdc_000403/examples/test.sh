#!/bin/sh

cd ../
path=`pwd`


BUFR_TABLES=$path/bufrtables/
export BUFR_TABLES

cd examples

./bufr_decode_all -i ../data/ISMD01_OKPR.bufr
