int main(void)
{
	return sizeof(long double) > sizeof(double) ? 0: 1;
}
