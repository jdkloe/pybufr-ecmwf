#!/bin/sh

cd ../
path=`pwd`


BUFR_TABLES=$path/bufrtables/
export BUFR_TABLES

cd examples

./decode_bufr -i ../data/ISMD01_OKPR.bufr
