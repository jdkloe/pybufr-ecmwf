C
C     'COMERROR' contains parameters need for manual error correction 
C
      COMMON / COMERROR / Nmode 
C
C                         Nmode=0  - Normal decoding
C                              =1  - Manual correction
