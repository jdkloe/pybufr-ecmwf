c
      common /comstd/sh(513),p(513)
c
c            sh  - array,  geopotential heights of stamdard atmosphere
c            p   - array,  pressure of standard atmosphere 
c
