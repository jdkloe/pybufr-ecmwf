#ifndef FORTINT_H
#define FORTINT_H

#ifdef INTEGER_IS_INT
#define fortint int
#else
#if defined hpR64 || defined hpiaR64
#define fortint long long
#else
#define fortint long
#endif
#endif

#endif /* end of  FORTINT_H */
