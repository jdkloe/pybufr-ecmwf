C
C     Common blocks holding default or user supplied values for printing.
C
      LOGICAL GRPRSET
      INTEGER GRPRSM
C
      COMMON /GRPRSCM/ GRPRSM, GRPRSET
