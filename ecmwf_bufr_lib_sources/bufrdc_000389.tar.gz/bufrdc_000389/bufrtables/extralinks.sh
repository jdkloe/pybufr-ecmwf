#!/bin/sh

for (( i=10; i <= 17   ; i++ ))
do
	for (( j=100; j <= 255  ; j++ ))
	do
		l=B0000000000${j}0${i}001.TXT
		f=B00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=D0000000000${j}0${i}001.TXT
		f=D00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=C0000000000${j}0${i}001.TXT
		f=C00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
	done
	for (( j=10; j <= 99  ; j++ ))
	do
		l=B00000000000${j}0${i}001.TXT
		f=B00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=D00000000000${j}0${i}001.TXT
		f=D00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=C00000000000${j}0${i}001.TXT
		f=C00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
	done
	for (( j=1; j <= 9  ; j++ ))
	do
		l=B000000000000${j}0${i}001.TXT
		f=B00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=D000000000000${j}0${i}001.TXT
		f=D00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
		l=C000000000000${j}0${i}001.TXT
		f=C00000000000980${i}001.TXT
		if [ ! -a $l ]
		then
			if [ -a $f ]
			then
				ln -s $f $l
			fi
		fi
	done
done



