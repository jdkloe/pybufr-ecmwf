#!/usr/bin/ksh

set -e

if [ $# -ne 2 ]
then
	echo usage: $0 tables_directory new_tables_directory
	exit 1
fi

dir=$1
newdir=$2
if [ ! -d $newdir ]
then
	mkdir $newdir
fi

for f in $dir/B*.TXT
do
	if [ -f $f ]
	then
		file=`basename $f`
		echo $file
		cp $f $newdir/$file
	fi
done

for f in $dir/C*.TXT
do
	if [ -f $f ]
	then
		file=`basename $f`
		echo $file
		#perl tableCcheck.pl $f 
		perl tableC2new_format.pl $f $newdir/$file
	fi
done

for f in $dir/D*.TXT
do
	if [ -f $f ]
	then
		file=`basename $f`
		echo $file
		cp $f $newdir/$file
	fi
done

if [ -f $dir/links.sh ]
then
	cp $dir/links.sh $newdir/links.sh
	cd $newdir
	./links.sh
fi


