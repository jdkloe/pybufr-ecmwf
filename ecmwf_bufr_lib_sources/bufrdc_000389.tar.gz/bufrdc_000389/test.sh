#!/bin/sh
set -e

path=`pwd`


BUFR_TABLES=$path/bufrtables/
export BUFR_TABLES

examples/bufr_decode_all -i data/ISMD01_OKPR.bufr | sed '/bufrtables/ d' > test.log
examples/bufr_decode_all -i data/IUSD40_OKLI.bufr | sed '/bufrtables/ d' >> test.log

set +e

diff test.log test.log.good
if [ $? != 0 ]
then
	echo "****************************************"
	echo "****************************************"
	echo TEST $0 FAILED              
	echo "****************************************"
	echo "****************************************"
	exit 1
fi

